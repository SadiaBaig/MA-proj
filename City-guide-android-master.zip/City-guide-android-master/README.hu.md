# City guide android
![](https://img.shields.io/badge/updated-july-yellow.svg)
[![License: GPL v3](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0) <br/>
<img src="https://github.com/konpa/devicon/blob/master/icons/android/android-plain-wordmark.svg" height=50> <br/>
*Read this in other languages: [English](README.md), [Hungarian](README.hu.md)* <br/>

## Intro
Ezt a projektet akkor készítettem amikor a [Reea](https://www.reea.net/) cégnél voltam gyakornok, 2018 júliusában.<br/>
Az alap ötlet a projekthez az volt, hogy egy kis útmutatást adjunk az embereknek, hogy milyen látványosságok vannak [Marosvásárhelyen](https://goo.gl/KNqWK5) és milyen tömegközlekedési lehetőségek vannak.

## Én előre szóltam...
További update-ek még érkezhetnek, mert a projekt még nincs kész. <br/>


## License and copyright
© Botond Sámuel Hegyi

Licensed under the [GPL v3.0 license](LICENSE).
