
# City guide android
![](https://img.shields.io/badge/updated-july-yellow.svg)
[![License: GPL v3](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](./LICENSE) <br/>
<img src="https://github.com/konpa/devicon/blob/master/icons/android/android-plain-wordmark.svg" height=50/> <br/>
*Read this in other languages: [English](README.md), [Hungarian](README.hu.md)* <br/>

## Introduction 
I made this project during my internship, at [Reea](https://www.reea.net/) company, in July 2018. <br>
The basic idea of this project, was helping out the people who came in [Targu Mures](https://goo.gl/KNqWK5), give them some basic information about the city, attractions and public transportation.

## I told you...
Further update may be coming, because the softwer is not finished and may be there is some bugs in it, so i have a lot of work with it.


## License and copyright
© Botond Sámuel Hegyi

Licensed under the [GPL v3.0 license](LICENSE).
